#!/usr/bin/env python  
# -*- coding:utf-8 -*- 
import json
from get_urltrain import d
import urllib2
import requests
from pprint import pprint
from get_urltrain import url
from prettytable import PrettyTable
from color_set import colored
from colorama import init, Fore
import sys
reload(sys)
sys.setdefaultencoding( "utf-8" )

def trains(available_trains,available_place):
        for raw_train in available_trains:
            raw_train_list = raw_train.split('|')
            train_no = raw_train_list[3]
            initial = train_no[0].lower()
            duration = raw_train_list[10]
            train = [
                train_no,
                '\n'.join([Fore.GREEN + available_place[raw_train_list[6]] + Fore.RESET,
                           Fore.RED + available_place[raw_train_list[7]] + Fore.RESET]),
                '\n'.join([Fore.GREEN + raw_train_list[8] + Fore.RESET,
                           Fore.RED + raw_train_list[9] + Fore.RESET]),
                duration,
                raw_train_list[-4] if raw_train_list[-4] else '--',
                raw_train_list[-5] if raw_train_list[-5] else '--',
                raw_train_list[-14] if raw_train_list[-14] else '--',
                raw_train_list[-12] if raw_train_list[-12] else '--',
                raw_train_list[-7] if raw_train_list[-7] else '--',
                raw_train_list[-6] if raw_train_list[-6] else '--',
                raw_train_list[-9] if raw_train_list[-9] else '--',
                ]
            yield train

r = requests.get(url, verify=False)
#print(r.content)
rows = r.json()['data']['result']
maps = r.json()['data']['map']
notrain= PrettyTable()
notrain.field_names=["车次","车站","时间","历时","一等座","二等座","高级软卧","软卧","硬卧 ","硬座","无座"]
#trains(rows,maps)
print trains
num = len(rows)
print ('查询结束，共有 %d 趟列车。'%num )
for test in trains(rows,maps):
	notrain.add_row(test)
print (notrain)
