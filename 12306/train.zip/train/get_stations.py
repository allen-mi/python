#!/usr/bin/env python
#coding:utf-8
import json
import re  
import urllib2  
#from urllib import request
import requests  
from pprint import pprint
import warnings
import sys
reload(sys)
sys.setdefaultencoding( "utf-8" )

url = 'https://kyfw.12306.cn/otn/resources/js/framework/station_name.js?station_version=1.9016'  
warnings.filterwarnings("ignore")
req = urllib2.Request(url)
response = urllib2.urlopen(req)  
r = response.read().decode('utf-8')
#print (r)  
stations =re.findall(ur'([\u4e00-\u9fa5]+)\|([A-Z]+)',r) #匹配中文和对应的英文  
stations = dict(stations)
#print stations
stations = dict(zip( stations.keys(),stations.values()))#将匹配的内容转化为字典  
ret_data = json.dumps(stations,ensure_ascii=False,indent=1,encoding='utf-8')
f = open("test.txt","w+")
print >> f,ret_data
f.close()
